﻿namespace Sports.Models
{
    public class Products
    {
        public int ProductId { get; set; }

        public string? ProductCode { get; set; }

        public string? Name { get; set; }

        public DateTime ReleaseDate { get; set; }

    }
}
